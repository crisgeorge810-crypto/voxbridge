# VoxBridge — Android prototype

This is the first UI prototype for the multilingual calling app.

## What is included
- Home screen
- Voice-call layout
- Video-call layout
- Calls tab
- Chat rooms tab
- Files tab
- Profile/settings tab
- Language selection concept
- Live translation ON/OFF control
- VoxBridge logo asset

## Important
This first build is a UI prototype. The real-time internet calling and speech-to-speech translation backend are intentionally not connected yet.

## Run
1. Install Flutter SDK and Android Studio on a computer.
2. Extract this project.
3. Open the folder in Android Studio or VS Code.
4. Run `flutter pub get`.
5. Connect an Android phone with USB debugging enabled, or start an Android emulator.
6. Run `flutter run`.

Next development stage: real two-user voice calling, then speech recognition → translation → translated speech, followed by video calling, chat rooms and file storage.
