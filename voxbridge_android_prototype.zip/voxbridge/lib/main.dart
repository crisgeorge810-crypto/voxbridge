import 'package:flutter/material.dart';

void main() => runApp(const VoxBridgeApp());

class VoxBridgeApp extends StatelessWidget {
  const VoxBridgeApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VoxBridge',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF061229),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF14B8FF), brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [HomeTab(), CallsTab(), ChatsTab(), FilesTab(), ProfileTab()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'Calls'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'Files'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [
        CircleAvatar(radius: 25, backgroundImage: const AssetImage('assets/voxbridge_logo.png')),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('VoxBridge', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text('Speak your language. Understand the world.', style: TextStyle(color: Colors.white60, fontSize: 12))])),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ]),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF0B5AA0), Color(0xFF16214A)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Real-time translation', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Talk naturally while VoxBridge translates the conversation live.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CallPage(video: false))), icon: const Icon(Icons.call), label: const Text('Voice call'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CallPage(video: true))), icon: const Icon(Icons.videocam), label: const Text('Video'))),
        ])
      ])),
      const SizedBox(height: 24),
      const Text('Your languages', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const CircleAvatar(child: Text('NG')), title: const Text('I speak'), subtitle: const Text('Igbo'), trailing: const Icon(Icons.chevron_right))),
      Card(child: ListTile(leading: const CircleAvatar(child: Text('ES')), title: const Text('I want to hear'), subtitle: const Text('Spanish'), trailing: const Icon(Icons.chevron_right))),
      const SizedBox(height: 16),
      const Text('Quick actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.5, children: const [
        QuickCard(Icons.translate, 'Languages'), QuickCard(Icons.groups_2_outlined, 'Chat rooms'), QuickCard(Icons.upload_file, 'Upload file'), QuickCard(Icons.person_add_alt_1, 'Add contact'),
      ])
    ]);
  }
}

class QuickCard extends StatelessWidget { final IconData icon; final String text; const QuickCard(this.icon, this.text, {super.key}); @override Widget build(BuildContext context) => Card(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 30), const SizedBox(height: 8), Text(text)])); }

class CallsTab extends StatelessWidget { const CallsTab({super.key}); @override Widget build(BuildContext context) => const SimpleListPage(title: 'Calls', icon: Icons.call, items: ['Maria — Spanish', 'Chinedu — Igbo', 'David — English']); }
class ChatsTab extends StatelessWidget { const ChatsTab({super.key}); @override Widget build(BuildContext context) => const SimpleListPage(title: 'Chats & rooms', icon: Icons.chat, items: ['World Travelers', 'Business English', 'Igbo Learners']); }
class FilesTab extends StatelessWidget { const FilesTab({super.key}); @override Widget build(BuildContext context) => const SimpleListPage(title: 'Files', icon: Icons.folder, items: ['Welcome.pdf', 'Voice message.m4a', 'Shared photo.jpg']); }
class ProfileTab extends StatelessWidget { const ProfileTab({super.key}); @override Widget build(BuildContext context) => const SimpleListPage(title: 'Profile & settings', icon: Icons.person, items: ['Account', 'My languages', 'Notifications', 'Privacy & security']); }

class SimpleListPage extends StatelessWidget { final String title; final IconData icon; final List<String> items; const SimpleListPage({required this.title, required this.icon, required this.items, super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const SizedBox(height: 18), ...items.map((e) => Card(child: ListTile(leading: CircleAvatar(child: Icon(icon)), title: Text(e), trailing: const Icon(Icons.chevron_right))))]); }

class CallPage extends StatefulWidget { final bool video; const CallPage({required this.video, super.key}); @override State<CallPage> createState() => _CallPageState(); }
class _CallPageState extends State<CallPage> { bool translation = true; @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.video ? 'Video call' : 'Voice call')), body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), color: const Color(0xFF101D38)), child: widget.video ? const Center(child: Icon(Icons.person, size: 100, color: Colors.white24)) : const Center(child: CircleAvatar(radius: 58, child: Icon(Icons.person, size: 70))))), const SizedBox(height: 16), const Text('Maria', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const Text('Spanish • Connected', style: TextStyle(color: Colors.white60)), const SizedBox(height: 12), Card(child: SwitchListTile(value: translation, onChanged: (v) => setState(() => translation = v), title: const Text('Live translation'), subtitle: const Text('Igbo → Spanish / Spanish → Igbo'), secondary: const Icon(Icons.translate))), const Spacer(), Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [CircleAvatar(radius: 28, child: IconButton(onPressed: () {}, icon: const Icon(Icons.mic_off))), CircleAvatar(radius: 34, backgroundColor: Colors.red, child: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.call_end))), CircleAvatar(radius: 28, child: IconButton(onPressed: () {}, icon: const Icon(Icons.volume_up)))])]))); }
